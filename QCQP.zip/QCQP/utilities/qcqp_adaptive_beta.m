function [tau, beta, count_p, count_d] = qcqp_adaptive_beta(k, pinf, dinf, tau, beta, count_p, count_d)
    % Preserve the update schedule of the original benchmark's adaptive_beta.p.
    if k < 22
        required = 4;
    elseif k < 62
        required = 7;
    elseif k < 122
        required = 51;
    else
        required = 101;
    end

    ratio = pinf / dinf;
    if ratio <= .8
        count_p = count_p + 1;
        count_d = 0;
        if count_p >= required
            tau = .8 * tau;
            beta = beta / .8^2;
            count_p = 0;
        end
    elseif ratio > 1.25
        count_p = 0;
        count_d = count_d + 1;
        if count_d >= required
            tau = tau / .8;
            beta = .8^2 * beta;
            count_d = 0;
        end
    end
end
