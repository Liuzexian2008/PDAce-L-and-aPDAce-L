function value = qcqp_reference_value(input, solver)
    [A, Q, b, d, c, ~, lb, ub] = input{1:8};
    n = numel(b);
    m = numel(c);
    cvx_begin quiet
        cvx_solver(char(solver));
        cvx_precision high
        variable x(n)
        minimize(0.5 * quad_form(x, A) + b' * x)
        subject to
        for j = 1:m
            0.5 * quad_form(x, Q{j}) + d(j, :) * x <= c(j);
        end
        lb <= x;
        x <= ub;
    cvx_end
    if ~contains(cvx_status, 'Solved') || ~isfinite(cvx_optval)
        error('PDAce_L_QCQP:ReferenceSolve', 'CVX failed to compute a reference objective with %s (%s).', solver, cvx_status);
    end
    value = cvx_optval;
end
