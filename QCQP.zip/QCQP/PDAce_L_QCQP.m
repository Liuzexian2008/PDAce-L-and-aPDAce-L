function [rel_infeas_err, rel_subopt_err, time_period, iter_epoch, inner_iter] = PDAce_L_QCQP(input, prox, optval, x0, y0, stop_criteria, max_iter)
    A = input{1, 1};
    b = input{3, 1};
    d = input{4, 1};
    lb = input{7, 1};
    ub = input{8, 1};
    beta0 = 10;
    [m, ~] = size(d);
    optval_rel = max(abs(optval), 1);
    epoch = 1;
    epoch_counter = 0;
    alpha = 0.86;
    varphi = 1.2;
    mu = 0.7;
    tau_max = 1e6;
    c_ls = 0.25;
    delta_ls = 0.0001;
    if c_ls <= 0 || c_ls >= 1
        error('c_ls must satisfy 0 < c_ls < 1.');
    end
    if delta_ls <= 0 || delta_ls >= 1-c_ls
        error('delta_ls must satisfy 0 < delta_ls < 1-c_ls.');
    end
    beta = beta0;
    rel_subopt_err = [];
    rel_infeas_err = [];
    y = y0;
    z = (1-alpha)*x0;
    q = zeros(size(y));
    iter = 0;
    inner_iter = zeros(max_iter, 1);
    tau_old = 0.01;
    tau_old = min(tau_old, tau_max);
    tic;
    while iter < max_iter
        iter = iter + 1;
        p = qcqp_grad_y(input, z);
        if iter == 1
            tau_trial = tau_old;
        else
            tau_trial = min(varphi*tau_old, tau_max);
        end
        while true
            tau = tau_trial;
            sigma = beta*tau;
            if iter == 1
                theta = 0;
            else
                theta = tau_old/tau;
            end
            s = p + theta*q;
            ytild = prox.f(y + sigma*s);
            ydiff = ytild-y;
            G_x_trial = qcqp_grad_x(input, z, ytild);
            xtild = max(min(z-tau*G_x_trial, ub), lb);
            xbar_diff = xtild-z;
            G_y_xnew = qcqp_grad_y(input, xtild);
            q_new = G_y_xnew-p;
            phi_xnew = phi_qcqp(A, b, xtild, ytild, G_y_xnew);
            phi_z = phi_qcqp(A, b, z, ytild, p);
            Lambda = phi_xnew - phi_z - G_x_trial'*xbar_diff;
            LS_LHS = Lambda + sigma/(2*c_ls)*norm(q_new)^2;
            LS_RHS = ((1-delta_ls)*(1+alpha)/(2*tau)) * norm(xbar_diff)^2 + ((1-c_ls-delta_ls)/(2*sigma)) * norm(ydiff)^2;
            Err = LS_LHS-LS_RHS;
            if Err <= 0
                break;
            else
                inner_iter(iter) = inner_iter(iter)+1;
                tau_trial = mu*tau;
            end
        end
        z_new = alpha*z + (1-alpha)*xtild;
        pinf = norm(ydiff, 1)/(beta*tau);
        G_x_stop = qcqp_grad_x(input, xtild, ytild);
        dinf = qcqp_box_normal_distance(G_x_stop, xtild, lb, ub) /(1+norm(xtild, 1));
        x = xtild;
        y = ytild;
        z = z_new;
        q = q_new;
        tau_old = tau;
        if mod(iter, epoch) == 0
            epoch_counter = epoch_counter+1;
            time_period(epoch_counter, 1) = toc;
            if isempty(A)
                subopt = b'*x;
            else
                subopt = 0.5*x'*A*x+b'*x;
            end
            infeas = sum(max(G_y_xnew, 0));
            rel_subopt_err(epoch_counter, 1) = abs(subopt-optval)/optval_rel;
            rel_infeas_err(epoch_counter, 1) = infeas/m;
            iter_epoch(epoch_counter, 1) = iter;
            if ((rel_subopt_err(epoch_counter) < stop_criteria.f && rel_infeas_err(epoch_counter) < stop_criteria.inf) && max(pinf, dinf) < 1e-6) || max(pinf, dinf) < 1e-7
                return;
            end
        end
    end
end

function val = phi_qcqp(A, b, x, y, Gx)
    if isempty(A)
        obj = b'*x;
    else
        obj = 0.5*x'*A*x+b'*x;
    end
    val = obj + y(:)'*Gx(:);
end
