function [rel_infeas_err, rel_subopt_err, time_period, iter_epoch, inner_iter] = aPDAc_L_QCQP(input, prox, optval, x0, y0, stop_criteria, max_iter)
    % Written by xiaokai Chang, created on 2022.06.18.
    A = input{1, 1};
    b = input{3, 1};
    d = input{4, 1};
    gamma_g = input{6, 1};
    lb = input{7, 1};
    ub = input{8, 1};
    beta0 = input{9, 1};
    input{1, 1} = A-gamma_g*eye(size(A));
    [n, ~] = size(d);
    optval_rel = max(abs(optval), 1);
    epoch = 1;
    epoch_counter = 0;
    psi = 2; rho = 6/5;
    xi = psi - psi^3*rho/(2*(1+psi));
    w = 2*psi -xi- psi^3*rho/(1+psi);
    mu = 0.7;
    delta = 1;
    beta_old = beta0;
    rel_subopt_err = [];
    rel_infeas_err = [];
    y = y0;   x = x0;   z = x0;
    iter = 0;   orc = 0;
    inner_iter = zeros(max_iter, 1);
    G_x = qcqp_grad_x(input, x, y);
    x_ = x + rand(size(x)) * 1e-10;
    G_x_ = qcqp_grad_x(input, x_, y);
    if norm(G_x - G_x_) > 0
        tau = norm(x - x_)/norm(G_x - G_x_);
    else
        tau = 1e-3;
    end
    tau_old = tau;
    tic;
    while iter<max_iter
        iter = iter+1;
        z = (psi-1)/psi * x +1/psi * z;
        xtild = max(min((z - tau_old * G_x)/(1+tau_old*gamma_g), ub), lb);
        xdiff = xtild-x;
        G_y = qcqp_grad_y(input, xtild);
        om = (psi-rho)/(psi + rho*gamma_g*tau_old);
        beta = (1 + gamma_g * om *tau_old)* beta_old;
        tau = min(tau_old * rho, 1e+6);
        while true
            ytild = prox.f(y + beta*tau * G_y);
            ydiff = ytild-y;
            G_x1 = qcqp_grad_x(input, xtild, ytild);
            k_n = w * delta + gamma_g * tau_old;
            R = norm(ydiff)^2/beta + beta_old/beta*k_n *norm(xdiff)^2;
            Err = tau_old/xi * norm(G_x- G_x1)^2- R/tau;
            if Err <= 0
                break;
            else
                inner_iter(iter) = inner_iter(iter)+1;
                tau = tau*mu;
            end
        end
        delta = tau_old/tau;
        x = xtild; y = ytild; tau_old = tau; G_x = G_x1; beta_old = beta;
        if mod(iter, epoch) == 0
            epoch_counter = epoch_counter+1;
            time_period(epoch_counter, 1) = toc;
            if isempty(A)
                subopt = b'*x;
            else
                subopt = 0.5*x'*A'*x+b'*x;
            end
            infeas = sum(max(G_y, 0));
            rel_subopt_err(epoch_counter, 1) = abs(subopt-optval)/abs(optval_rel);
            rel_infeas_err(epoch_counter, 1) = infeas/n;
            iter_epoch(epoch_counter, 1) = iter;
            if abs(subopt-optval)/abs(optval_rel)<stop_criteria.f && infeas/n<stop_criteria.inf
                return;
            end
        end
    end
end
