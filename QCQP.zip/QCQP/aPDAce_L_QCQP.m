function [rel_infeas_err, rel_subopt_err, time_period, iter_epoch, inner_iter] = aPDAce_L_QCQP(input, prox, optval, x0, y0, stop_criteria, max_iter)
    A = input{1, 1};
    b = input{3, 1};
    d = input{4, 1};
    gamma_g = input{6, 1};
    lb = input{7, 1};
    ub = input{8, 1};
    gamma0 = input{9, 1};
    [m, ~] = size(d);
    optval_rel = max(abs(optval), 1);
    input_sc = input;
    nvar = size(A, 1);
    if issparse(A)
        input_sc{1, 1} = A - gamma_g*speye(nvar);
    else
        input_sc{1, 1} = A - gamma_g*eye(nvar);
    end
    A_sc = input_sc{1, 1};
    epoch = 1;
    epoch_counter = 0;
    alpha = 0.76;
    varphi = 1.2;
    eta = 0.7;
    c_ls = 0.25;
    delta_ls = 1e-3;
    tau_max = 1e6;
    max_ls_iter = 1000;
    if gamma_g <= 0
        error('gamma_g must be strictly positive.');
    end
    if gamma0 <= 0
        error('gamma0 must be strictly positive.');
    end
    if ~(alpha > 0 && alpha < 1)
        error('alpha must satisfy 0 < alpha < 1.');
    end
    if ~(varphi >= 1)
        error('varphi must satisfy varphi >= 1.');
    end
    if ~(eta > 0 && eta < 1)
        error('eta must satisfy 0 < eta < 1.');
    end
    if ~(c_ls > 0 && c_ls < 1)
        error('c_ls must satisfy 0 < c_ls < 1.');
    end
    if ~(delta_ls >= 0 && delta_ls < 1-c_ls)
        error('delta_ls must satisfy 0 <= delta_ls < 1-c_ls.');
    end
    if alpha*varphi >= 1
        error(['aPDAce-L theory requires alpha*varphi < 1. ', 'Current alpha*varphi = %.6f.'], alpha*varphi);
    end
    rel_subopt_err = [];
    rel_infeas_err = [];
    time_period = [];
    iter_epoch = [];
    inner_iter = zeros(max_iter, 1);
    x = x0;
    y = y0;
    z = x0;
    q_old = zeros(size(y));
    iter = 0;
    tau0 = 1e-2;
    tau0 = min(tau0, tau_max);
    tau_old = tau0;
    gamma_old = gamma0;
    sigma_old = gamma0*tau0;
    tic;
    while iter < max_iter
        iter = iter+1;
        p = qcqp_grad_y(input, z);
        if iter == 1
            tau_hat = tau0;
        else
            tau_hat = min(varphi*tau_old, tau_max*sqrt(gamma0/gamma_old));
        end
        tau = tau_hat;
        ls_counter = 0;
        while true
            if iter == 1
                gamma = gamma0;
            else
                gamma = gamma_old*(1 + gamma_g*tau_old)/(1 + alpha*gamma_g*tau);
            end
            sigma = gamma*tau;
            if iter == 1
                theta = 0;
            else
                theta = sigma_old/sigma;
            end
            s = p + theta*q_old;
            ytild = prox.f(y + sigma*s);
            ydiff = ytild-y;
            G_x = qcqp_grad_x(input_sc, z, ytild);
            xtild = max(min((z - tau*G_x)/(1 + tau*gamma_g), ub), lb);
            xdiff = xtild-z;
            G_xtild = qcqp_grad_y(input, xtild);
            q_trial = G_xtild-p;
            if norm(xdiff) > 1e-5*max(1, norm(z))
                phi_x = 0.5*xtild'*A_sc*xtild + b'*xtild + ytild(:)'*G_xtild(:);
                phi_z = 0.5*z'*A_sc*z + b'*z + ytild(:)'*p(:);
                Lambda = phi_x-phi_z-G_x'*xdiff;
            else
                G_x_end = qcqp_grad_x(input_sc, xtild, ytild);
                Lambda = 0.5*(G_x_end-G_x)'*xdiff;
            end
            T1 = Lambda;
            T2 = sigma/(2*c_ls)*norm(q_trial)^2;
            B1 = (1-delta_ls)*(1+alpha)/(2*tau)*norm(xdiff)^2;
            B2 = (1-c_ls-delta_ls)/(2*sigma)*norm(ydiff)^2;
            LS_LHS = T1+T2;
            LS_RHS = B1+B2;
            Err = LS_LHS-LS_RHS;
            if Err <= 0
                break;
            end
            ls_counter = ls_counter+1;
            inner_iter(iter) = ls_counter;
            if ls_counter >= max_ls_iter
                error('Maximum line-search iterations reached.');
            end
            tau = eta*tau;
        end
        x_new = xtild;
        y_new = ytild;
        q_new = q_trial;
        z_new = alpha*z + (1-alpha)*x_new;
        if mod(iter, epoch) == 0
            epoch_counter = epoch_counter+1;
            time_period(epoch_counter, 1) = toc;
            if isempty(A)
                subopt = b'*x_new;
            else
                subopt = 0.5*x_new'*A*x_new + b'*x_new;
            end
            infeas = sum(max(G_xtild, 0));
            rel_subopt_err(epoch_counter, 1) = abs(subopt-optval)/optval_rel;
            rel_infeas_err(epoch_counter, 1) = infeas/m;
            iter_epoch(epoch_counter, 1) = iter;
            if rel_subopt_err(epoch_counter) < stop_criteria.f && rel_infeas_err(epoch_counter) < stop_criteria.inf
                return;
            end
        end
        x = x_new;
        y = y_new;
        z = z_new;
        q_old = q_new;
        tau_old = tau;
        gamma_old = gamma;
        sigma_old = sigma;
    end
end
