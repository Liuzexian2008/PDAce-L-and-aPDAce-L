function [rel_infeas_err, rel_subopt_err, time_period, iter_epoch, inner] = APDB_QCQP(input, optval, x0, y0, stop_criteria, max_iter)
    % Written by Erfan Yazdandoost Hamedani, created on 14 November 2018.
    A = input{1, 1};
    Q = input{2, 1};
    b = input{3, 1};
    d = input{4, 1};
    c = input{5, 1};
    sc = input{6, 1};
    A_0 = A-sc*eye(size(A));
    [n, ~] = size(d);
    optval_rel = max(abs(optval), 1);
    epoch = 1;
    epoch_counter = 0;
    eta = 0.7;
    tau = 1e-3;
    gamma = 1;
    sigma_old = gamma*tau;
    tau_old = tau;
    mu = sc;
    rel_subopt_err = [];
    rel_infeas_err = [];
    y = y0;
    x = x0;
    iter = 0;
    inner = zeros(max_iter, 1);
    for j = 1:n
        G_y(j, 1) = 0.5*x'*Q{j, 1}*x+d(j, :)*x-c(j);
    end
    tic;
    while iter<max_iter
        iter = iter+1;
        G_y_old = G_y;
        for j = 1:n
            G_y(j, 1) = 0.5*x'*Q{j, 1}*x+d(j, :)*x-c(j);
        end
        while true
            sigma = gamma*tau;
            theta = sigma_old/sigma;
            ytild = max(y+sigma*((1+theta)*G_y-theta*G_y_old), 0);
            G_x = A_0*x+b;
            for j = 1:n
                G_x = G_x+(Q{j, 1}*x+d(j, :)')*ytild(j);
            end
            xtild = max(min((x-tau*G_x)/(1+tau*sc), 10), -10);
            xdiff = xtild-x;
            E = 0;
            aux = 0;
            for j = 1:n
                E = E+((xdiff)'*Q{j, 1}*(xdiff))*ytild(j);
                aux = aux+norm(0.5*xtild'*Q{j, 1}*xtild-0.5*x'*Q{j, 1}*x+d(j, :)*(xdiff))^2;
            end
            E = E+xdiff'*A_0*xdiff-norm(xdiff)^2/(2*tau)+(sigma)*aux/2;
            if E<=0
                break;
            else
                inner(iter) = inner(iter) + 1;
                tau = tau*eta;
            end
        end
        gamma_old = gamma;
        gamma = gamma*(1+mu*tau);
        tau_new = tau*sqrt(gamma_old/gamma *(1+tau/tau_old));
        sigma_old = sigma;
        tau_old = tau;
        tau = tau_new;
        y = ytild;
        x = xtild;
        if mod(iter, epoch) == 0
            epoch_counter = epoch_counter+1;
            time_period(epoch_counter, 1) = toc;
            subopt = 0.5*x'*A'*x+b'*x;
            infeas = 0;
            for l = 1:n
                infeas = infeas+max(0.5*x'*Q{l, :}*x+d(l, :)*x-c(l), 0);
            end
            rel_subopt_err(epoch_counter, 1) = abs(subopt-optval)/abs(optval_rel);
            rel_infeas_err(epoch_counter, 1) = infeas/n;
            iter_epoch(epoch_counter, 1) = iter;
            if abs(subopt-optval)/abs(optval_rel)<stop_criteria.f && infeas/n<stop_criteria.inf
                return;
            end
        end
    end
end
