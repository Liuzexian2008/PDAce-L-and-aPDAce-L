function [rel_infeas_err, rel_subopt_err, time_period, iter_epoch, inner] = PDB_QCQP(input, optval, x0, y0, stop_criteria, max_iter)
    % Written by Erfan Yazdandoost Hamedani, created on 14 November 2018.
    A = input{1, 1};
    Q = input{2, 1};
    b = input{3, 1};
    d = input{4, 1};
    c = input{5, 1};
    lb = input{7, 1};
    ub = input{8, 1};
    sc = 0;
    [n, ~] = size(d);
    optval_rel = max(abs(optval), 1);
    epoch = 1;
    epoch_counter = 0;
    eta = 0.7;
    tau = 1e-3;
    gamma = 1;
    sigma_old = gamma*tau;
    tau_old = tau;
    mu = sc;
    rel_subopt_err = [];
    rel_infeas_err = [];
    y = y0;
    x = x0;
    iter = 0;
    inner = zeros(max_iter, 1);
    G_y = qcqp_grad_y(input, x);
    tic;
    while iter<max_iter
        iter = iter+1;
        G_y_old = G_y;
        G_y = qcqp_grad_y(input, x);
        while true
            sigma = gamma*tau;
            theta = sigma_old/sigma;
            ytild = max(y+sigma*((1+theta)*G_y-theta*G_y_old), 0);
            G_x = qcqp_grad_x(input, x, ytild);
            xtild = max(min(x-tau*G_x, ub), lb);
            E = qcqp_linesearch_error(input, tau, sigma, x, xtild, ytild);
            if E<=0
                break;
            else
                inner(iter) = inner(iter)+1;
                tau = tau*eta;
            end
        end
        gamma_old = gamma;
        gamma = gamma*(1+mu*tau);
        tau_new = tau*sqrt(gamma_old/gamma *(1+tau/tau_old));
        sigma_old = sigma;
        tau_old = tau;
        tau = tau_new;
        y = ytild;
        x = xtild;
        if mod(iter, epoch) == 0
            epoch_counter = epoch_counter+1;
            time_period(epoch_counter, 1) = toc;
            if isempty(A)
                subopt = b'*x;
            else
                subopt = 0.5*x'*A'*x+b'*x;
            end
            infeas = 0;
            for l = 1:n
                if isempty(Q{l, :})
                    infeas = infeas+max(d(l, :)*x-c(l), 0);
                else
                    infeas = infeas+max(0.5*x'*Q{l, :}*x+d(l, :)*x-c(l), 0);
                end
            end
            rel_subopt_err(epoch_counter, 1) = abs(subopt-optval)/abs(optval_rel);
            rel_infeas_err(epoch_counter, 1) = infeas/n;
            iter_epoch(epoch_counter, 1) = iter;
            if abs(subopt-optval)/abs(optval_rel)<stop_criteria.f && infeas/n<stop_criteria.inf
                return;
            end
        end
    end
end
