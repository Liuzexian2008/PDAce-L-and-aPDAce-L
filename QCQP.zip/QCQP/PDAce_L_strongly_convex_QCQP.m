function [rel_infeas_err, rel_subopt_err, time_period, iter_epoch, inner_iter] = PDAce_L_strongly_convex_QCQP(input, prox, optval, x0, y0, stop_criteria, max_iter)
    A = input{1, 1};
    b = input{3, 1};
    d = input{4, 1};
    gamma_g = input{6, 1};
    lb = input{7, 1};
    ub = input{8, 1};
    beta0 = input{9, 1};
    [m, ~] = size(d);
    optval_rel = max(abs(optval), 1);
    if gamma_g <= 0
        error('gamma_g must be strictly positive.');
    end
    if beta0 <= 0
        error('beta0 must be strictly positive.');
    end
    if isempty(A)
        error('Strongly convex QCQP requires a nonempty quadratic matrix A.');
    end
    input_sc = input;
    nvar = size(A, 1);
    if issparse(A)
        input_sc{1, 1} = A - gamma_g*speye(nvar);
    else
        input_sc{1, 1} = A - gamma_g*eye(nvar);
    end
    A_sc = input_sc{1, 1};
    epoch = 1;
    epoch_counter = 0;
    alpha = 0.76;
    varphi = 1.2;
    eta = 0.7;
    c_ls = 0.25;
    delta_ls = 1e-3;
    tau_max = 1e6;
    max_ls_iter = 1000;
    if ~(alpha > 0 && alpha < 1)
        error('alpha must satisfy 0 < alpha < 1.');
    end
    if ~(varphi >= 1)
        error('varphi must satisfy varphi >= 1.');
    end
    if ~(eta > 0 && eta < 1)
        error('eta must satisfy 0 < eta < 1.');
    end
    if ~(c_ls > 0 && c_ls < 1)
        error('c_ls must satisfy 0 < c_ls < 1.');
    end
    if ~(delta_ls >= 0 && delta_ls < 1-c_ls)
        error('delta_ls must satisfy 0 <= delta_ls < 1-c_ls.');
    end
    rel_subopt_err = [];
    rel_infeas_err = [];
    time_period = [];
    iter_epoch = [];
    inner_iter = zeros(max_iter, 1);
    x = x0;
    y = y0;
    z = x0;
    q = zeros(size(y));
    iter = 0;
    tau0 = 1e-2;
    tau0 = min(tau0, tau_max);
    tau_old = tau0;
    tic;
    while iter < max_iter
        iter = iter+1;
        p = qcqp_grad_y(input, z);
        if iter == 1
            tau_trial = tau0;
        else
            tau_trial = min(varphi*tau_old, tau_max);
        end
        ls_counter = 0;
        while true
            tau = tau_trial;
            sigma = beta0*tau;
            if iter == 1
                theta = 0;
            else
                theta = tau_old/tau;
            end
            s = p + theta*q;
            ytild = prox.f(y + sigma*s);
            ydiff = ytild-y;
            G_x_trial = qcqp_grad_x(input_sc, z, ytild);
            xtild = max(min((z - tau*G_x_trial)/(1 + tau*gamma_g), ub), lb);
            xbar_diff = xtild-z;
            G_y_xnew = qcqp_grad_y(input, xtild);
            q_new = G_y_xnew-p;
            if norm(xbar_diff) > 1e-5*max(1, norm(z))
                phi_xnew = 0.5*xtild'*A_sc*xtild + b'*xtild + ytild(:)'*G_y_xnew(:);
                phi_z = 0.5*z'*A_sc*z + b'*z + ytild(:)'*p(:);
                Lambda = phi_xnew - phi_z - G_x_trial'*xbar_diff;
            else
                G_x_end = qcqp_grad_x(input_sc, xtild, ytild);
                Lambda = 0.5*(G_x_end-G_x_trial)'*xbar_diff;
            end
            T1 = Lambda;
            T2 = sigma/(2*c_ls)*norm(q_new)^2;
            B1 = (1-delta_ls)*(1+alpha)/(2*tau)*norm(xbar_diff)^2;
            B2 = (1-c_ls-delta_ls)/(2*sigma)*norm(ydiff)^2;
            LS_LHS = T1+T2;
            LS_RHS = B1+B2;
            Err = LS_LHS-LS_RHS;
            if Err <= 0
                break;
            end
            ls_counter = ls_counter+1;
            inner_iter(iter) = ls_counter;
            if ls_counter >= max_ls_iter
                error('Maximum line-search iterations reached.');
            end
            tau_trial = eta*tau;
        end
        z_new = alpha*z + (1-alpha)*xtild;
        x = xtild;
        y = ytild;
        z = z_new;
        q = q_new;
        tau_old = tau;
        if mod(iter, epoch) == 0
            epoch_counter = epoch_counter+1;
            time_period(epoch_counter, 1) = toc;
            subopt = 0.5*x'*A*x + b'*x;
            infeas = sum(max(G_y_xnew, 0));
            rel_subopt_err(epoch_counter, 1) = abs(subopt-optval)/optval_rel;
            rel_infeas_err(epoch_counter, 1) = infeas/m;
            iter_epoch(epoch_counter, 1) = iter;
            if rel_subopt_err(epoch_counter) < stop_criteria.f && rel_infeas_err(epoch_counter) < stop_criteria.inf
                return;
            end
        end
    end
end
