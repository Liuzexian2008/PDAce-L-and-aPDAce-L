function [rel_infeas_err, rel_subopt_err, time_period, iter_epoch, inner_iter] = PDAc_L_QCQP(input, para_ls, prox, optval, adp_beta, x0, y0, stop_criteria, max_iter)
    % Written by xiaokai Chang, created on 2022.06.18.
    A = input{1, 1};
    b = input{3, 1};
    d = input{4, 1};
    lb = input{7, 1};
    ub = input{8, 1};
    beta0 = input{9, 1};
    [n, ~] = size(d);
    optval_rel = max(abs(optval), 1);
    epoch = 1;
    epoch_counter = 0;
    psi = 2; rho = 6/5;
    xi = psi - psi^3*rho/(2*(1+psi));
    w = 2*psi -xi- psi^3*rho/(1+psi);
    mu = 0.7;
    delta = 1;
    if adp_beta == 1
        beta = 1;
    else
        beta = beta0;
    end
    C = [0]; M = para_ls.M; nu = para_ls.nu;  eta = para_ls.eta;
    rel_subopt_err = [];
    rel_infeas_err = [];
    y = y0;
    x = x0;
    z = (1-1/psi)*x0;
    iter = 0;
    inner_iter = zeros(max_iter, 1);
    it_pinf = 0;
    it_dinf = 0;
    G_x = qcqp_grad_x(input, x, y);
    y_ = y + rand(size(y)) * 1e-10;
    G_x_ = qcqp_grad_x(input, x, y_);
    if norm(G_x - G_x_) > 0
        tau = max(1e-3, mu * xi/(2*beta)* norm(y - y_)^2/norm(G_x - G_x_)^2);
    else
        tau = 1e-3;
    end
    tau_old = tau;
    tic;
    while iter<max_iter
        iter = iter+1;
        z = (psi-1)/psi * x +1/psi * z;
        xtild = max(min(z - tau_old * G_x, ub), lb);
        xdiff = xtild-x;
        G_y = qcqp_grad_y(input, xtild);
        tau = min(tau_old * rho, 1e+6);
        while true
            ytild = prox.f(y + beta*tau * G_y);
            ydiff = ytild-y;
            G_x1 = qcqp_grad_x(input, xtild, ytild);
            R = norm(ydiff)^2/beta + w * delta *norm(xdiff)^2;
            Err = tau_old/xi * norm(G_x- G_x1)^2 - (nu * R +(1-nu)* eta/length(C) * sum(C))/tau;
            if Err <= 0
                if length(C) <= M
                    C(end+1) = R;
                else
                    C(end+1) = R;  C = C(2:end);
                end
                break;
            else
                inner_iter(iter) = inner_iter(iter)+1;
                tau = tau*mu;
            end
        end
        delta = tau/tau_old;
        pinf = norm(ydiff, 1)/(beta*tau);
        dinf = qcqp_box_normal_distance(G_x, xtild, lb, ub)/(1+norm(xtild, 1));
        if adp_beta == 1
            [tau, beta, it_pinf, it_dinf] = qcqp_adaptive_beta(iter, pinf, dinf, tau, beta, it_pinf, it_dinf);
        end
        x = xtild;   y = ytild;   tau_old = tau; G_x = G_x1;
        if mod(iter, epoch) == 0
            epoch_counter = epoch_counter+1;
            time_period(epoch_counter, 1) = toc;
            if isempty(A)
                subopt = b'*x;
            else
                subopt = 0.5*x'*A'*x+b'*x;
            end
            infeas = sum(max(G_y, 0));
            rel_subopt_err(epoch_counter, 1) = abs(subopt-optval)/abs(optval_rel);
            rel_infeas_err(epoch_counter, 1) = infeas/n;
            iter_epoch(epoch_counter, 1) = iter;
            if ((abs(subopt-optval)/abs(optval_rel)<stop_criteria.f && infeas/n<stop_criteria.inf) && max(pinf, dinf)<1e-6) ||  max(pinf, dinf)<1e-7
                return;
            end
        end
    end
end
