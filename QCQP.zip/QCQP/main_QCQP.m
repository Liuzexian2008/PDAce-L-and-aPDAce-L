function results = main_QCQP(options)
    % Run the convex or strongly convex QCQP benchmark from Section 6.
    % Use StronglyConvex=true for the accelerated comparison and CVXSolver="sdpt3" for SDPT3.
    % Benchmark setup adapted from Xiaokai Chang's QCQP experiments.
    arguments
        options.StronglyConvex (1, 1) logical = false
        options.NumVariables (1, 1) double {mustBeInteger, mustBePositive} = 500
        options.NumConstraints (1, 1) double {mustBeInteger, mustBePositive} = 30
        options.NumRuns (1, 1) double {mustBeInteger, mustBePositive} = 10
        options.MaxIterations (1, 1) double {mustBeInteger, mustBeNonnegative} = 0
        options.Seed (1, 1) double {mustBeInteger, mustBeNonnegative} = 123
        options.CVXSolver (1, 1) string = "mosek"
        options.Plot (1, 1) logical = true
    end

    original_path = path;
    restore_path = onCleanup(@() path(original_path));
    addpath(fullfile(fileparts(mfilename('fullpath')), 'utilities'), '-begin');

    if exist('cvx_begin', 'file') == 0
        error('PDAce_L_QCQP:MissingCVX', 'Install and configure CVX before running this benchmark.');
    end
    if options.StronglyConvex
        methods = {'aPDAc-L', 'PDAc-L(F)', 'APDB', 'aPDAce-L', 'PDAce-L'};
        default_max_iter = 1e4;
        beta0 = 1;
        plot_title = 'Strongly convex QCQP';
    else
        methods = {'PDAc-L(A)', 'PDAc-L(F)', 'PDB', 'PDAce-L'};
        default_max_iter = 5e4;
        beta0 = 50;
        plot_title = 'Convex QCQP';
    end
    max_iter = options.MaxIterations;
    if max_iter == 0
        max_iter = default_max_iter;
    end

    previous_rng = rng;
    restore_rng = onCleanup(@() rng(previous_rng));
    rand('seed', options.Seed);
    randn('seed', options.Seed);
    n = options.NumVariables;
    m = options.NumConstraints;
    x0 = rand(n, 1);
    y0 = zeros(m, 1);
    lb = -10 * ones(n, 1);
    ub = 10 * ones(n, 1);
    prox.f = @(y) max(y, 0);
    tol = struct('inf', 1e-8, 'f', 1e-8);
    line_search = struct('M', 5, 'nu', .9, 'eta', .9);
    runs = cell(numel(methods), options.NumRuns);
    reference = zeros(1, options.NumRuns);
    backtracks = zeros(size(runs));

    for sim = 1:options.NumRuns
        fprintf('%s, run %d/%d\n', plot_title, sim, options.NumRuns);
        basis = orth(randn(n));
        spectrum = 100 * rand(n - 1, 1);
        if options.StronglyConvex
            A = basis' * diag([spectrum + 1; 1]) * basis;
            strong_convexity = min(eig(A));
        else
            A = basis' * diag([spectrum; 1e-10]) * basis;
            strong_convexity = 0;
        end
        b = randn(n, 1);
        d = randn(m, n);
        Q = cell(m, 1);
        for j = 1:m
            basis = orth(randn(n));
            Q{j} = basis' * diag([100 * rand(n - 1, 1); 1e-10]) * basis;
        end
        c = rand(m, 1);
        input = {A; Q; b; d; c; strong_convexity; lb; ub; beta0};
        optval = qcqp_reference_value(input, options.CVXSolver);
        reference(sim) = optval;

        for j = 1:numel(methods)
            switch methods{j}
            case 'PDAc-L(A)'
                [con, obj, seconds, k, reductions] = PDAc_L_QCQP(input, line_search, prox, optval, true, x0, y0, tol, max_iter);
            case 'PDAc-L(F)'
                [con, obj, seconds, k, reductions] = PDAc_L_QCQP(input, line_search, prox, optval, false, x0, y0, tol, max_iter);
            case 'PDB'
                [con, obj, seconds, k, reductions] = PDB_QCQP(input, optval, x0, y0, tol, max_iter);
            case 'APDB'
                [con, obj, seconds, k, reductions] = APDB_QCQP(input, optval, x0, y0, tol, max_iter);
            case 'aPDAc-L'
                [con, obj, seconds, k, reductions] = aPDAc_L_QCQP(input, prox, optval, x0, y0, tol, max_iter);
            case 'aPDAce-L'
                [con, obj, seconds, k, reductions] = aPDAce_L_QCQP(input, prox, optval, x0, y0, tol, max_iter);
            case 'PDAce-L'
                if options.StronglyConvex
                    [con, obj, seconds, k, reductions] = PDAce_L_strongly_convex_QCQP(input, prox, optval, x0, y0, tol, max_iter);
                else
                    [con, obj, seconds, k, reductions] = PDAce_L_QCQP(input, prox, optval, x0, y0, tol, max_iter);
                end
            end
            runs{j, sim} = [k, seconds, obj, con];
            backtracks(j, sim) = sum(reductions(1:numel(k)));
            fprintf('  %-10s %6d iterations, %6d backtracks, %.3f s\n', methods{j}, k(end), backtracks(j, sim), seconds(end));
        end
    end

    results = struct('methods', {methods}, 'reference', reference, 'reference_solver', options.CVXSolver, 'runs', {runs}, 'backtracks', backtracks);
    results.columns = {'iteration', 'seconds', 'objective_residual', 'constraint_violation'};
    if options.Plot
        qcqp_plot_profiles(runs, methods, [3, 4], {'Relative objective residual', 'Average constraint violation'}, plot_title);
    end
end
