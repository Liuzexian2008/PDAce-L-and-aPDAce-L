function out = PDB_CCMMG(p, opts)
    if nargin < 2
        opts = struct;
    end
    base = struct('beta', 15, 'tau0', .001, 'tau_max', 1e6, 'rho', .7, 'max_ls', 200, 'max_iter', 2000, 'tol', 1e-8);
    o = ccmmg_set_defaults(opts, base);

    x = p.x0;
    y = p.y0;
    [g, J, ~, gh, t] = ccmmg_oracle(p, x);
    gprev = g;
    tau = o.tau0;
    tauold = tau;
    sigmaold = o.beta * tau;
    hist = zeros(o.max_iter, 9);
    trace = zeros(o.max_iter, 4);
    totalbt = 0;
    status = 'max_iter';

    timer = tic;

    for k = 1:o.max_iter
        accepted = false;

        for bt = 0:o.max_ls-1
            sigma = o.beta * tau;
            theta = sigmaold / sigma;
            yn = ccmmg_project_simplex(y + sigma * ((1 + theta) * g - theta * gprev));
            xn = ccmmg_project_simplex(x - tau * (gh + J * yn));
            [gn, Jn, tn, rem] = ccmmg_trial(p, x, xn, g, J, t, yn);
            lhs = 2 * rem + sigma / 2 * norm(gn - g)^2;
            rhs = norm(xn - x)^2 / (2 * tau);
            if isfinite(lhs) && lhs <= rhs
                accepted = true;
                break;
            end
            tau = o.rho * tau;
        end
        if ~accepted
            error('ccmmg:linesearch', 'PDB failed at iteration %d.', k);
        end

        gprev = g;
        x = xn;
        y = yn;
        g = gn;
        J = Jn;
        t = tn;
        [h, gh] = ccmmg_smooth(p, t);
        rx = norm(x - ccmmg_project_simplex(x - (gh + J * y)));
        ry = norm(y - ccmmg_project_simplex(y + g));
        res = max(rx, ry);
        totalbt = totalbt + bt;
        hist(k, :) = [k, toc(timer), res, h + y' * g, h + max(g), totalbt, tau, sigma, rx];
        trace(k, :) = [tau, sigma, bt, rhs - lhs];

        tau_next = min(o.tau_max, tau * sqrt(1 + tau / tauold));
        tauold = tau;
        sigmaold = sigma;
        tau = tau_next;

        if res < o.tol
            status = 'converged';
            break;
        end
    end

    out = struct('method', 'PDB', 'x', x, 'y', y, 'history', hist(1:k, :), 'trace', trace(1:k, :), 'options', o, 'status', status);

end
