function x_proj = ccmmg_project_simplex(v)
    n = length(v);
    u = sort(v, 'descend');
    cssv = cumsum(u);
    rho = find(u > (cssv - 1) ./ (1:n)', 1, 'last');
    theta = (cssv(rho) - 1) / rho;
    x_proj = max(v - theta, 0);
end
