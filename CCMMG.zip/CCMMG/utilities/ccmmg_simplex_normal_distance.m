function d = ccmmg_simplex_normal_distance(g, x)
    active = x>0;[v, idx] = sort(g);weights = 1+double(active(idx));
    target = sum(active);assert(target>0);
    t = v(find(cumsum(weights)>=target, 1));
    d = sum(abs(g(active)-t))+sum(max(t-g(~active), 0));
end
