function p = ccmmg_problem(seed, n, m)
    previous = rng;
    cleanup = onCleanup(@() rng(previous));
    rand('seed', seed);
    randn('seed', seed);

    p = struct('seed', seed, 'n', n, 'm', m, 'x0', rand(n, 1), 'y0', zeros(m, 1));
    p.A = randn(n);
    p.Q = cell(1, m);

    for j = 1:m
        [U, ~] = qr(randn(n, n));
        T = U * diag(logspace(0, 3, n)) * U';
        p.Q{j} = (T + T') / 2;
    end
    p.B = randn(n, m);
    p.C = randn(m, 1);
end
