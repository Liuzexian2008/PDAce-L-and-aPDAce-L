function options = ccmmg_set_defaults(options, defaults)
    names = fieldnames(defaults);
    for j = 1:numel(names)
        if ~isfield(options, names{j})
            options.(names{j}) = defaults.(names{j});
        end
    end
    validateattributes(options.max_iter, {'numeric'}, {'scalar', 'integer', 'positive'});
    validateattributes(options.tol, {'numeric'}, {'scalar', 'finite', 'nonnegative'});
    assert(options.beta > 0 && options.tau0 > 0);
    assert(options.rho > 0 && options.rho < 1);
end
