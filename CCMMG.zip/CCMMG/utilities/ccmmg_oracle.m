function [g, J, h, gh, t] = ccmmg_oracle(p, x)
    t = p.A * x;
    h = mean(max(t, 0) + log1p(exp(-abs(t))));
    s = zeros(size(t));
    pos = t >= 0;
    s(pos) = 1 ./ (1 + exp(-t(pos)));
    e = exp(t(~pos));
    s(~pos) = e ./ (1 + e);
    gh = p.A' * s / size(p.A, 1);
    V = zeros(p.n, p.m);
    for j = 1:p.m
        V(:, j) = p.Q{j} * x;
    end
    J = V + p.B;
    g = .5 * (x' * V)' + p.B' * x + p.C;
end
