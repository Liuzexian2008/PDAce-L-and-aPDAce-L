function ccmmg_plot_profiles(runs, methods, value_columns, ylabels, plot_title)
    colors = lines(numel(methods));
    fig = figure('Name', plot_title, 'Color', 'w');
    layout = tiledlayout(fig, numel(value_columns), 2, 'TileSpacing', 'compact');
    max_iter = max(cellfun(@(h) h(end, 1), runs), [], 'all');
    max_time = max(cellfun(@(h) h(end, 2), runs), [], 'all');
    grids = {(1:max_iter)', linspace(0, max_time, 1000)'};
    xlabels = {'Iterations', 'Elapsed time (s)'};

    for row = 1:numel(value_columns)
        for col = 1:2
            ax = nexttile(layout);
            hold(ax, 'on');
            grid(ax, 'on');
            grid_points = grids{col};
            for j = 1:numel(methods)
                aligned = zeros(numel(grid_points), size(runs, 2));
                for sim = 1:size(runs, 2)
                    history = runs{j, sim};
                    [axis_values, idx] = unique(history(:, col), 'last');
                    values = history(idx, value_columns(row));
                    if numel(axis_values) == 1
                        aligned(:, sim) = values;
                    else
                        query = min(max(grid_points, axis_values(1)), axis_values(end));
                        aligned(:, sim) = interp1(axis_values, values, query, 'nearest');
                    end
                end
                low = max(min(aligned, [], 2), 1e-15);
                high = max(max(aligned, [], 2), 1e-15);
                center = max(median(aligned, 2), 1e-15);
                color = colors(j, :);
                fill(ax, [grid_points; flipud(grid_points)], [low; flipud(high)], color, 'FaceAlpha', .18, 'EdgeColor', 'none', 'HandleVisibility', 'off');
                semilogy(ax, grid_points, center, 'Color', color, 'LineWidth', 1.6, 'DisplayName', methods{j});
            end
            set(ax, 'YScale', 'log', 'Layer', 'top');
            xlabel(ax, xlabels{col});
            ylabel(ax, ylabels{row});
            legend(ax, 'Location', 'best');
        end
    end
end
