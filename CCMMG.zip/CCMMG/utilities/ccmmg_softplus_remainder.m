function r = ccmmg_softplus_remainder(t, h)
    sp = @(v) max(v, 0) + log1p(exp(-abs(v)));
    s = zeros(size(t));
    pos = t >= 0;
    s(pos) = 1 ./ (1 + exp(-t(pos)));
    e = exp(t(~pos));
    s(~pos) = e ./ (1 + e);
    r = sp(t+h) - sp(t) - s .* h;
    small = abs(h) < .1;
    nodes = [.046910077030668 .230765344947158 .5 .769234655052842 .953089922969332];
    weights = [.118463442528095 .239314335249683 .284444444444444 .239314335249683 .118463442528095];
    q = zeros(sum(small), 1);
    for k = 1:5
        v = t(small) + nodes(k) * h(small);
        e = exp(-abs(v));
        q = q + weights(k) * (1-nodes(k)) * e ./ (1+e).^2;
    end
    r(small) = h(small).^2 .* q;
    r = mean(r);
end
