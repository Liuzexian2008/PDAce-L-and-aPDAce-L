function [h, gh] = ccmmg_smooth(p, t)
    h = mean(max(t, 0) + log1p(exp(-abs(t))));
    s = zeros(size(t));
    pos = t >= 0;
    s(pos) = 1 ./ (1 + exp(-t(pos)));
    e = exp(t(~pos));
    s(~pos) = e ./ (1 + e);
    gh = p.A' * s / size(p.A, 1);
end
