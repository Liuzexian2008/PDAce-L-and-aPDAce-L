function [g, J, t, rem] = ccmmg_trial(p, z, x, gz, Jz, tz, y)
    d = x - z;
    DQ = zeros(p.n, p.m);
    for j = 1:p.m
        DQ(:, j) = p.Q{j} * d;
    end
    quadratic = (d' * DQ)';
    g = gz + Jz' * d + .5 * quadratic;
    J = Jz + DQ;
    dt = p.A * d;
    t = tz + dt;
    rem = ccmmg_softplus_remainder(tz, dt) + .5 * y' * quadratic;
end
