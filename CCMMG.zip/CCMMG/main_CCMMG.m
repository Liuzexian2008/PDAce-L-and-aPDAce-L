function results = main_CCMMG(options)
    % Run the CCMMG comparison with PDAce-L, PDAc-L(A), and PDB.
    % The default generator and step cap match the archived CCMMG runs.
    arguments
        options.NumVariables (1, 1) double {mustBeInteger, mustBePositive} = 100
        options.NumGroups (1, 1) double {mustBeInteger, mustBePositive} = 300
        options.NumRuns (1, 1) double {mustBeInteger, mustBePositive} = 10
        options.MaxIterations (1, 1) double {mustBeInteger, mustBePositive} = 2000
        options.Seed (1, 1) double {mustBeInteger, mustBeNonnegative} = 1001
        options.Tolerance (1, 1) double {mustBeFinite, mustBePositive} = 1e-8
        options.PDAceStepCap (1, 1) double {mustBeFinite, mustBePositive} = .0036
        options.Plot (1, 1) logical = true
    end

    original_path = path;
    restore_path = onCleanup(@() path(original_path));
    addpath(fullfile(fileparts(mfilename('fullpath')), 'utilities'), '-begin');

    methods = {'PDB', 'PDAc-L(A)', 'PDAce-L'};
    solvers = {@PDB_CCMMG, @PDAc_L_CCMMG, @PDAce_L_CCMMG};
    base = struct('max_iter', options.MaxIterations, 'tol', options.Tolerance);
    pdace = base;
    pdace.tau_max = options.PDAceStepCap;
    pdace.tau0 = min(.001, pdace.tau_max);
    settings = {base, base, pdace};
    runs = cell(numel(methods), options.NumRuns);
    for sim = 1:options.NumRuns
        seed = options.Seed + sim - 1;
        fprintf('CCMMG, run %d/%d (seed %d)\n', sim, options.NumRuns, seed);
        problem = ccmmg_problem(seed, options.NumVariables, options.NumGroups);
        for j = circshift(1:numel(methods), sim - 1)
            run = solvers{j}(problem, settings{j});
            runs{j, sim} = run;
            fprintf('  %-10s %6d iterations, residual %.3e (%s)\n', methods{j}, run.history(end, 1), run.history(end, 3), run.status);
        end
    end

    results = struct('methods', {methods}, 'runs', {runs});
    results.columns = {'iteration', 'seconds', 'residual', 'objective', 'primal_objective', 'backtracks', 'tau', 'sigma', 'primal_residual'};
    if options.Plot
        histories = cellfun(@(run) run.history, runs, 'UniformOutput', false);
        ccmmg_plot_profiles(histories, methods, 3, {'Fixed-point residual'}, 'Convex-concave minimax game');
    end
end
