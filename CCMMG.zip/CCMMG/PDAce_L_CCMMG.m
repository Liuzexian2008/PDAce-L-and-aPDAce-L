function out = PDAce_L_CCMMG(p, opts)
    if nargin < 2
        opts = struct;
    end
    base = struct('alpha', .036, 'beta', 15, 'phi', 1.2, 'rho', .5, 'c', .97, 'delta', .001, 'tau0', .001, 'tau_max', 1e6, 'max_iter', 2000, 'tol', 1e-8, 'max_ls', 200);
    opts = ccmmg_set_defaults(opts, base);
    assert(opts.alpha > 0 && opts.alpha < 1 && opts.c > 0 && opts.c < 1);
    assert(opts.delta > 0 && opts.delta < 1 - opts.c);

    x = p.x0;
    y = p.y0;
    z = (1 - opts.alpha) * x;
    q = zeros(p.m, 1);
    tauold = opts.tau0;
    history = zeros(opts.max_iter, 9);
    trace = zeros(opts.max_iter, 4);
    totalbt = 0;
    status = 'max_iter';

    timer = tic;

    for k = 1:opts.max_iter
        if k == 1 || mod(k - 1, 50) == 0
            [pz, Jz, ~, ghz, tz] = ccmmg_oracle(p, z);
        else
            [~, ghz] = ccmmg_smooth(p, tz);
        end
        tau = opts.tau0;
        if k > 1
            tau = min(opts.phi * tauold, opts.tau_max);
        end
        accepted = false;

        for bt = 0:opts.max_ls-1
            sigma = opts.beta * tau;
            theta = 0;
            if k > 1
                theta = tauold / tau;
            end
            yn = ccmmg_project_simplex(y + sigma * (pz + theta * q));
            gx = ghz + Jz * yn;
            xn = ccmmg_project_simplex(z - tau * gx);
            d = xn - z;
            DQ = zeros(p.n, p.m);
            for j = 1:p.m
                DQ(:, j) = p.Q{j} * d;
            end
            quadratic = (d' * DQ)';
            qn = Jz' * d + .5 * quadratic;
            en = pz + qn;
            dt = p.A * d;
            rem = ccmmg_softplus_remainder(tz, dt) + .5 * yn' * quadratic;
            lhs = rem + sigma / (2 * opts.c) * norm(qn)^2;
            rhs = (1 - opts.delta) * (1 + opts.alpha) / (2 * tau) * norm(d)^2 + (1 - opts.c - opts.delta) / (2 * sigma) * norm(yn - y)^2;
            if isfinite(lhs) && isfinite(rhs) && lhs <= rhs
                accepted = true;
                break;
            end
            tau = opts.rho * tau;
        end
        if ~accepted
            error('ccmmg:linesearch', 'PDAce-L failed at iteration %d.', k);
        end

        totalbt = totalbt + bt;
        x = xn;
        y = yn;
        z = opts.alpha * z + (1 - opts.alpha) * x;
        q = qn;
        tauold = tau;

        tx = tz + dt;
        s = zeros(size(tx));
        pos = tx >= 0;
        s(pos) = 1 ./ (1 + exp(-tx(pos)));
        e = exp(tx(~pos));
        s(~pos) = e ./ (1 + e);
        gh = p.A' * s / size(p.A, 1);
        Jx = Jz + DQ;
        rx = norm(x - ccmmg_project_simplex(x - (gh + Jx * y)));
        ry = norm(y - ccmmg_project_simplex(y + en));
        residual = max(rx, ry);
        hx = mean(max(tx, 0) + log1p(exp(-abs(tx))));
        history(k, :) = [k, toc(timer), residual, hx + y' * en, hx + max(en), totalbt, tau, sigma, rx];
        trace(k, :) = [tau, sigma, bt, rhs - lhs];

        v = 1 - opts.alpha;
        pz = pz + v * qn - .5 * v * opts.alpha * quadratic;
        Jz = Jz + v * DQ;
        tz = tz + v * dt;

        if residual < opts.tol
            status = 'converged';
            break;
        end
    end

    out = struct('method', 'PDAce-L', 'x', x, 'y', y, 'history', history(1:k, :), 'trace', trace(1:k, :), 'options', opts, 'status', status);

end
