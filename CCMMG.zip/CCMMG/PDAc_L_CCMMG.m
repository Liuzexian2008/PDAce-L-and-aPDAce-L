function out = PDAc_L_CCMMG(p, opts)
    if nargin < 2
        opts = struct;
    end
    base = ccmmg_pdac_qcqp_options(struct('max_ls', 200, 'max_iter', 2000, 'tol', 1e-8));
    o = ccmmg_set_defaults(opts, base);

    x = p.x0;
    y = p.y0;
    z = x;
    if o.qcqp_initialization
        z = (1 - 1 / o.psi) * x;
    end
    [g, J, ~, gh, t] = ccmmg_oracle(p, x);
    gx = gh + J * y;
    tauold = o.tau0;
    ratio = 1;
    memory = [];
    totalbt = 0;
    status = 'max_iter';
    beta = o.beta;
    it_pinf = 0;
    it_dinf = 0;
    beta_history = zeros(o.max_iter, 1);
    if o.qcqp_initialization
        memory = 0;
        stream = RandStream('mt19937ar', 'Seed', p.seed);
        dy = rand(stream, size(y)) * 1e-10;
        dg = J * dy;
        if norm(dg) > 0
            tauold = max(.001, o.rho * o.xi / (2 * beta) * norm(dy)^2 / norm(dg)^2);
        end
    end
    omega = 2 * o.psi - o.xi - o.psi^3 * o.phi / (1 + o.psi);
    assert(omega > 0);
    hist = zeros(o.max_iter, 9);
    trace = zeros(o.max_iter, 4);

    timer = tic;

    for k = 1:o.max_iter
        z = (o.psi - 1) / o.psi * x + z / o.psi;
        xn = ccmmg_project_simplex(z - tauold * gx);
        [gn, Jn, tn] = ccmmg_trial(p, x, xn, g, J, t, zeros(p.m, 1));
        [h, ghn] = ccmmg_smooth(p, tn);
        tau = min(o.phi * tauold, o.tau_max);
        accepted = false;

        for bt = 0:o.max_ls-1
            sigma = beta * tau;
            yn = ccmmg_project_simplex(y + sigma * gn);
            gxn = ghn + Jn * yn;
            R = omega * ratio * norm(xn - x)^2 + norm(yn - y)^2 / beta;
            c = 0;
            if ~isempty(memory)
                c = o.eta * mean(memory);
            end
            lhs = tau * tauold / o.xi * norm(gxn - gx)^2;
            rhs = o.nu * R + (1 - o.nu) * c;
            if isfinite(lhs) && lhs <= rhs
                accepted = true;
                break;
            end
            tau = o.rho * tau;
        end
        if ~accepted
            error('ccmmg:linesearch', 'PDAc-L failed at iteration %d.', k);
        end

        memory = [memory, R];
        keep = o.memory + double(o.qcqp_initialization);
        memory = memory(max(1, end - keep + 1):end);
        beta_history(k) = beta;
        ratio = tau / tauold;
        nexttau = tau;

        if o.adaptive_beta
            pinf = norm(yn - y, 1) / (beta * tau);
            dinf = ccmmg_simplex_normal_distance(gx, xn) / (1 + norm(xn, 1));
            [nexttau, beta, it_pinf, it_dinf] = ccmmg_adaptive_beta( k, pinf, dinf, tau, beta, it_pinf, it_dinf);
        end

        tauold = nexttau;
        x = xn;
        y = yn;
        g = gn;
        J = Jn;
        t = tn;
        gx = gxn;
        rx = norm(x - ccmmg_project_simplex(x - gx));
        ry = norm(y - ccmmg_project_simplex(y + g));
        res = max(rx, ry);
        totalbt = totalbt + bt;
        hist(k, :) = [k, toc(timer), res, h + y' * g, h + max(g), totalbt, tau, sigma, rx];
        trace(k, :) = [tau, sigma, bt, rhs - lhs];

        if res < o.tol
            status = 'converged';
            break;
        end
    end

    out = struct('method', 'PDAc-L(A)', 'x', x, 'y', y, 'history', hist(1:k, :), 'trace', trace(1:k, :), 'options', o, 'status', status, 'beta_history', beta_history(1:k));

end

function options = ccmmg_pdac_qcqp_options(overrides)
    if nargin < 1
        overrides = struct;
    end
    options = struct('beta', 1, 'adaptive_beta', true, 'qcqp_initialization', true, 'psi', 2, 'phi', 6/5, 'xi', .4, 'rho', .7, 'nu', .9, 'eta', .9, 'memory', 5, 'tau0', .001, 'tau_max', 1e6);
    names = fieldnames(overrides);
    for j = 1:numel(names)
        options.(names{j}) = overrides.(names{j});
    end
end
